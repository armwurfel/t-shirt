import React, { Component } from 'react';
import Main from '../sections/main/Main';

class Home extends Component {
    render() {
        return (
            <Main />
        )
    }
}

export default Home
