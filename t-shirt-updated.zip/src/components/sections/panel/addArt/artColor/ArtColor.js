import React, { Component } from 'react';
import ColorSelection from '../../../../utilitiesComponent/colorSelection/ColorSelection';
import CardHeader from '../../../../utilitiesComponent/cardHeader/CardHeader';

class ArtColor extends Component {
    constructor(props) {
        super(props);
        this.state = {
            colorName: "Black",
            colorId: this.props.artColor
        }
    }
    render() {
        return (
            <div className="card">
                <CardHeader back="/artTools" title="Art Colors" />
                <ColorSelection handleArtColor={this.props.handleArtColor} colorName={this.state.colorName} colorId={this.state.colorId} />
            </div>
        )
    }
}

export default ArtColor
