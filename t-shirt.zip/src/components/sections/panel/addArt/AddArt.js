import React, { Component } from 'react';
import CardHeader from '../../../utilitiesComponent/cardHeader/CardHeader';

import './addart.css'
class AddArt extends Component {
    render() {
        return (
            <div className="card">
                <CardHeader title="Add Art" />
            </div>
        )
    }
}

export default AddArt
