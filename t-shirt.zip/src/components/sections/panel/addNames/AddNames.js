import React, { Component } from 'react';
import CardHeader from '../../../utilitiesComponent/cardHeader/CardHeader';
import './addnames.css'

class AddNames extends Component {
    render() {
        return (
            <div className="card">
                 <CardHeader title="Add Names" />
            </div>
        )
    }
}

export default AddNames
