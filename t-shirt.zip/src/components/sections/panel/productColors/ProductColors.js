import React, { Component } from 'react';
import CardHeader from '../../../utilitiesComponent/cardHeader/CardHeader';

import './productcolors.css';

class ProductColors extends Component {
    render() {
        return (
            <div className="card">
                 <CardHeader title="Product Colors" />
            </div>
        )
    }
}

export default ProductColors
