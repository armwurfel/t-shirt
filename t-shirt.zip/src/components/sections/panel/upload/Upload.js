import React, { Component } from 'react';
import CardHeader from '../../../utilitiesComponent/cardHeader/CardHeader';

import './upload.css';

class Upload extends Component {
    render() {
        return (
            <div className="card">
                 <CardHeader title="Upload" />
            </div>
        )
    }
}

export default Upload
